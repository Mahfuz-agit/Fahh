# BG Audio Recorder

Android app. Records audio in background. Shows past recordings.

## How to build
1. Open folder in Android Studio.
2. Let Gradle sync.
3. Run on device or emulator (min SDK 26).

## Features
- Start / Pause / Resume / Stop recording
- Runs as foreground service (survives app minimize)
- Saves .m4a files to app's external storage folder
- List of past recordings, tap to play

## Notes
- Grant microphone + notification permission when prompted.
- Files saved in Android/data/com.example.bgrecorder/files/
